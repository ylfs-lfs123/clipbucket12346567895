<?php
require_once '../includes/admin_config.php';
$userquery->logout();
redirect_to('index.php');
?>